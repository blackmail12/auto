kingkurnia - pstore
Oke ini tutorialnya gan

silahkan download termux diplaystore lalu ikuti langkah ini
tulis di termuxnya
1. Upload file Autovisitor ke akun github sobat, silahkan cari di google untuk tutorial buat akunnya
----->lalu di termux.
2. pkg install git ( ikuti saja jika ana Y/n ketik Y lalu enter )
3. pkg install python
4. pkg install python2
5. git clone "link github tempat upload filenya"
contoh : git clone https://github.com/kingkurnia/Autovisitor
6. cd Autovisitor
7. python2 zz.py proxylist.txt


untuk edit proxy silahkan sobat edit file Autovisitor cari proxy.txt lalu ulangi lagi dari langkah ke 5
sebelumnya delet dulu file sebelumnya dengan perintah
1. buka ulang termuxnya
2. ketik "rm -rf Autovisitor" tanpa tanda petik
3. lanjutkan langkah ke 5
